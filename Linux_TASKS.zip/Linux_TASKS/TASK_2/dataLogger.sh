touch demand_data.txt
echo "Store new data in here" >> demand_data.txt
touch demands.log
date >> demands.log
